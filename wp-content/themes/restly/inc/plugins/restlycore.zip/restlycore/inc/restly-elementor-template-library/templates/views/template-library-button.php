<script type="text/template" id="rave-TemplateLibrary_insert-button">
	<a class="elementor-template-library-template-action elementor-button raveTemplateLibrary_insert-button footer-live-preview">
		<i class="eicon-file-download" aria-hidden="true"></i>
		<span class="elementor-button-title"><?php esc_html_e( 'Insert', 'restlycore' ); ?></span>
	</a>
</script>